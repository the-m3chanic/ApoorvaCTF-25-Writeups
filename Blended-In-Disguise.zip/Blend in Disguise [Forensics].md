# Blend in Disguise [Forensics]

### Author: proximuz

### Flag: apoorvctf{bl3nd3r_1s_fuN}

```
Description: You'll never find me, I blend in so well.
```
Given `Hint.txt` and `chal.blend`

Hint.txt ->
```
Gather values, sum with care,
At every key, a weight to bear.
Tip the scales—one thousand’s gate,
Decide the path, control the fate.

One side dark, the other light,
Opposing forces, black and white.
Balance shifts, the truth unveiled,
A sight well known, a tale retold.
```

On opening the challenge file in blender we see keystamps at [0, 24, 48, 72, 96]


writing a script to extract the scaling for every cube persent (i.e 625 (25x25))
```py
import bpy

keyframes = [0, 24, 48, 72, 96]

data = []

for obj in bpy.data.objects:
    if "Cube" in obj.name:  
        x, y = round(obj.location.x), round(obj.location.y)  
        scale_values = {}

        for frame in keyframes:
            bpy.context.scene.frame_set(frame)
            scale_values[frame] = int(round(obj.scale.z)) 
        
        data.append((obj.name, x, y, scale_values))


output_path = "C:/Users/Jodhil Lal/Downloads/all_cubes_scaling.csv"
with open(output_path, "w") as f:

    f.write("Object, X, Y, " + ", ".join([f"Scale_{kf}" for kf in keyframes]) + "\n")

    for cube in data:
        name, x, y, scales = cube
        scale_values_str = ", ".join(str(scales[kf]) for kf in keyframes)
        f.write(f"{name}, {x}, {y}, {scale_values_str}\n")

print(f" All cube scaling values extracted and saved to {output_path}")

```

we extract the scaling values for each cube from the csv as shown below in the sample data :
```csv
Object	 X	 Y	 Scale_0	 Scale_24	 Scale_48	 Scale_72	 Scale_96
Cube	0	0	161	213	214	155	265
Cube.001	0	1	265	237	268	224	85
Cube.002	0	2	229	213	174	165	318
Cube.003	0	3	240	256	230	184	122
Cube.004	0	4	211	233	247	266	122
Cube.005	0	5	256	253	190	198	143
Cube.006	0	6	190	228	232	250	142
Cube.007	0	7	157	222	181	171	192
Cube.008	0	8	182	177	197	156	219
Cube.009	0	9	154	157	216	241	228
Cube.010	0	10	215	223	194	246	137
Cube.011	0	11	167	232	238	175	144
Cube.012	0	12	261	192	263	233	115
Cube.013	0	13	229	171	166	201	264
Cube.014	0	14	250	159	219	180	217
Cube.015	0	15	178	169	159	162	389
Cube.016	0	16	169	254	195	163	245
Cube.017	0	17	209	167	163	212	172
```

Now using a python script to plot keeping threshold as 1000 for the values obtained : 
```py
import numpy as np
import matplotlib.pyplot as plt
import csv


file_path = "scaling.csv"

cube_data = {}

with open(file_path, "r") as f:
    reader = csv.reader(f)
    next(reader)  

    for row in reader:
        if len(row) < 8: 
            print(f"Skipping line: {row}")
            continue

        obj_name = row[0]
        x, y = int(row[1]), int(row[2])
        scale_values = list(map(int, row[3:])) 

        cube_data[(x, y)] = sum(scale_values)

matrix = np.zeros((25, 25), dtype=int)

for (x, y), total_scale in cube_data.items():
    matrix[y, x] = 1 if total_scale > 1000 else 0 


matrix = 1 - matrix

def plot_qr(matrix, title, filename):
    plt.imshow(matrix, cmap="gray", interpolation="nearest")
    plt.axis("off")
    plt.title(title)
    plt.savefig(filename, dpi=300, bbox_inches="tight")
    plt.show()

plot_qr(matrix, "Generated QR Code", "qr_code.png")

print("QR code saved as 'qr_code.png'")
```

we get the qr code

 ![alt text](qr_code.png)

 scanning the qr we get the flag.