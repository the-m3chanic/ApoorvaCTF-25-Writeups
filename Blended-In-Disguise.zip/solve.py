import numpy as np
import matplotlib.pyplot as plt
import csv


file_path = "all_cubes_scaling.csv"

cube_data = {}

with open(file_path, "r") as f:
    reader = csv.reader(f)
    next(reader)  

    for row in reader:
        if len(row) < 8: 
            print(f"Skipping line: {row}")
            continue

        obj_name = row[0]
        x, y = int(row[1]), int(row[2])
        scale_values = list(map(int, row[3:])) 

        cube_data[(x, y)] = sum(scale_values)

matrix = np.zeros((25, 25), dtype=int)

for (x, y), total_scale in cube_data.items():
    matrix[y, x] = 1 if total_scale > 1000 else 0 


matrix = 1 - matrix

def plot_qr(matrix, title, filename):
    plt.imshow(matrix, cmap="gray", interpolation="nearest")
    plt.axis("off")
    plt.title(title)
    plt.savefig(filename, dpi=300, bbox_inches="tight")
    plt.show()

plot_qr(matrix, "Generated QR Code", "qr_code.png")

print("QR code saved as 'qr_code.png'")